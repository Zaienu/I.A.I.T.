using System;
using System.Collections.Generic;
using Editor.Tools_Scripts.Setup.Object_Setup;
using Entities_Core_Scripts;
using UnityEditor;
using UnityEditor.UIElements;
using UnityEngine;
using UnityEngine.UIElements;
using Button = UnityEngine.UIElements.Button;
using EntityManager = Editor.Tools_Scripts.Data_Management.EntityManager;
using UnityEditorInternal;
using static Utility.UnityExtension;

namespace Editor.Tools_Scripts.Setup.Global_Setup
{
    internal enum TYPE
    {
        ETAG,
        ELAYER,
        OTAG,
        OLAYER,
    }

    public class Tool_GlobalSetup : EditorWindow
    {
        [SerializeField] private VisualTreeAsset UXML_UI;
        [SerializeField] private VisualTreeAsset CheckBox;
        [SerializeField] private EntityManager EManager;
        [SerializeField] private ObjectManager OManager;

        private ListView[] listViews;
        private bool[][] dataLists;
        private string[][] unityData;

        //Menu Tab Attribute
        [MenuItem("Window/I.A.I.T./Setup/Global Setup Tool")]
        public static void InitWindow()
        {
            EditorWindow window = GetWindow<Tool_GlobalSetup>();
            window.titleContent = new GUIContent("Global Setup Tool");
            window.minSize = new Vector2(435, 450);
            window.maxSize = new Vector2(435, 450);
        }

        public void CreateGUI()
        {
            if (!Application.isEditor)
            {
                return;
            }

            UXML_UI.CloneTree();

            TemplateContainer container = UXML_UI.Instantiate();
            rootVisualElement.Add(container);

            ListView ETagCheckList = rootVisualElement.Q<ListView>("ETagCheckList", "Check_List");
            ListView ELayerCheckList = rootVisualElement.Q<ListView>("ELayerCheckList", "Check_List");

            ListView OTagCheckList = rootVisualElement.Q<ListView>("OTagCheckList", "Check_List");
            ListView OLayerCheckList = rootVisualElement.Q<ListView>("OLayerCheckList", "Check_List");
            
            Button Refresh = rootVisualElement.Q<Button>("RefreshButton", "Refresh_Button");
            
            Refresh.RegisterCallback<ClickEvent>(RefreshLists);

            void InitListViews()
            {
                listViews = new ListView[4];
                listViews[0] = ETagCheckList;
                listViews[1] = ELayerCheckList;
                listViews[2] = OTagCheckList;
                listViews[3] = OLayerCheckList;
            }

            void InitDataLists()
            {
                dataLists = new bool[4][];
                dataLists[0] = EManager.Tags;
                dataLists[1] = EManager.Layers;
                dataLists[2] = OManager.Tags;
                dataLists[3] = OManager.Layers;
            }

            void InitUnityData()
            {
                unityData = new string[2][];
                unityData[0] = InternalEditorUtility.tags;
                unityData[1] = InternalEditorUtility.layers;
            }
            
            //List Delegates
            Func<VisualElement> makeItem = null;
            Action<VisualElement, int> bindItem = null;
            Action<VisualElement, int> unbindItem = null;
            Action<VisualElement> destroyItem = null;
            
            GroupBox CloneCheckBox()
            {
                //Clone TagBox_UXML and find the TagBox Item
                VisualElement root = CheckBox.CloneTree();
                return root.Q<GroupBox>("Root", "Root_Check_Box");
            }

            void InitData()
            {
                EManager.Tags = ResizeArray(EManager.Tags, unityData[0].Length);
                EManager.Layers = ResizeArray(EManager.Layers, unityData[1].Length);
                
                OManager.Tags = ResizeArray(OManager.Tags, unityData[0].Length);
                OManager.Layers = ResizeArray(OManager.Layers, unityData[1].Length);
            }
            
            void Initialization()
            {
                InitListViews();
                InitUnityData();
                InitData();
                InitDataLists();
            }

            Initialization();

            ListView FindContainingListView(VisualElement _element)
            {
                //Search through the parent element if one is a ListView
                VisualElement current = _element;
                while (current != null)
                {
                    if (current is ListView listView)
                    {
                        return listView;
                    }

                    current = current.parent;
                }

                return null; // Return null if the ListView is not found
            }

            TYPE DetermineType(VisualElement _element)
            {
                ListView list = FindContainingListView(_element);

                if (list.name == "ETagCheckList")
                {
                    return TYPE.ETAG;
                }

                if (list.name == "ELayerCheckList")
                {
                    return TYPE.ELAYER;
                }

                if (list.name == "OTagCheckList")
                {
                    return TYPE.OTAG;
                }

                if (list.name == "OLayerCheckList")
                {
                    return TYPE.OLAYER;
                }

                return 0;
            }

            makeItem = () =>
            {
                GroupBox groupBox = CloneCheckBox();

                return groupBox;
            };

            bindItem = (_element, _index) =>
            {
                //Check Whether the element is a TagField and is valid
                Toggle toBind = _element.Q<Toggle>("ToggleBox", "Toggle_Box");
                if (toBind == null)
                {
                    return;
                }

                TYPE type = DetermineType(toBind);
                int id = type == TYPE.ELAYER || type == TYPE.OLAYER ? 1 : 0;
                toBind.text = unityData[id][_index];

                //Set Value according to list index
                toBind.SetValueWithoutNotify(dataLists[(int)type][_index]);
                
                //Bind the Function that will modify the value when it is changed in UI
                toBind.RegisterCallback<ChangeEvent<bool>>(_evt => OnCheckBoxValueChanged(_evt, _index, type));
            };
            
            unbindItem = (_element, _index) =>
            {
                //Check Whether the element is a TagField and is valid
                Toggle toUnbind = _element.Q<Toggle>("ToggleBox", "Toggle_Box");
                if (toUnbind == null)
                {
                    return;
                }

                TYPE type = DetermineType(_element);

                //Set Basic Value
                toUnbind.SetValueWithoutNotify(false);

                //Unregister the Callback to avoid any double registrations
                toUnbind.UnregisterCallback<ChangeEvent<bool>>(_evt => OnCheckBoxValueChanged(_evt, _index, type));
            };

            destroyItem = (_element) =>
            {
                GroupBox toRemove = _element as GroupBox;
                if (toRemove == null)
                {
                    return;
                }
            };
            void OnCheckBoxValueChanged(ChangeEvent<bool> _evt, int _index, TYPE _type)
            {
                dataLists[(int)_type][_index] = _evt.newValue;
            }

            void InitLists()
            {
                for (int i = 0; i < listViews.Length; i++)
                {
                    listViews[i].makeItem = makeItem;
                    listViews[i].bindItem = bindItem;
                    listViews[i].unbindItem = unbindItem;
                    listViews[i].destroyItem = destroyItem;
                    listViews[i].selectionType = SelectionType.None;
                    listViews[i].itemsSource = dataLists[i];
                    listViews[i].style.height = 5 * 25 + 6;
                    listViews[i].showBoundCollectionSize = false;
                    listViews[i].fixedItemHeight = 25;
                    listViews[i].Rebuild();
                }
            }

            InitLists();
        }
        
        public void RefreshLists(ClickEvent _evt)
        {
            for (int i = 0; i < listViews.Length; i++)
            {
                listViews[i].RefreshItems();
                listViews[i].Rebuild();
            }
        }
    }
}