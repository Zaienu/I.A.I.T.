using UnityEngine;

namespace Entities_Core_Scripts
{
    public class CLOSEST//eventual rename
    {
        public GameObject entity;
        public float distance;
    }
}
