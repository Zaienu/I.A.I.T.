namespace Entities_Core_Scripts
{
    public static class EntityManager
    {

    }
}
