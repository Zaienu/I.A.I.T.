using UnityEngine;

namespace Obstacles_Core_Scripts
{
    public class Obstacle_Core : MonoBehaviour
    {
        private void Start()
        {

        }
    }
}